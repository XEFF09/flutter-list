import 'package:flutter/material.dart';
import 'package:week3/FoodMenu.dart';

class Page3 extends StatelessWidget {

  final FoodMenu foodMenu;

  const Page3({
    super.key,
    required this.foodMenu
    });

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}